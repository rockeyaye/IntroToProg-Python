#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Rockey Aye
# Date:  Aug 20, 2018
# Change Log: New
# Change Description:  Rockey Aye, 8/19/2016, Create code to complete assignment 6
# 1.    Make a function for the code that loads the each rows of data
#       you have in the ToDo.txt text file into a python Dictionary
#       and adds it to a Python List.
# 2.    Make a function for the code that displays the contents of the List to the user.
# 3.    Make a function for the code that allows the user
#       to Add or Remove tasks from the list, plus save the tasks in the List
#       tasks-priorities using numbered choices.
# 4.    Make a function for the code that saves the data from the table
#       into the Todo.txt file when the program exits.
# 5.    Make a Class to hold the functions.
#-------------------------------------------------#

#--- DATA ---#
File = "C:\_PythonClass\ToDo.txt"
strData = ""
dicRow = {}
lstTable = []

#--- PROCESSING ---#
# Setting up class for the collection of functions
class ToDoList(object):
    @staticmethod
    # Step 1
    # Loading data from ToDo.txt in Python dictionary
    def readFile():
        objFile = open(File, "r")
        for line in objFile:
            strData = line.split(",")
            dicRow = {"task": strData[0].strip(), "priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()

    # Step 2
    # Display a menu of choices to the user
    # Part of Presentation Section


    # Step 3
    # Display current task ToDo list to the user
    def showList(message):
        print(message)
        for row in lstTable:
            print(row["task"] + " : " + row["priority"])

    # Step 4
    # Add a new item to the list/Table
    #User input on the task and its priority
    def addItem(message2):
        strTask = ()
        while not strTask:
            strTask = str(input("Please Enter Task: ")).strip().title()
        strPriority = ()
        while not strPriority:
            strPriority = str(input("Please Enter Priority (High, Medium, Low): ")).strip().title()
        print("\nYou've Added Task:", strTask, " & Priority:", strPriority)
        dicRow = {"task": strTask, "priority": strPriority}
        lstTable.append(dicRow)
        # print out the updated list
        print(message2)

    # Step 5
    # Remove an existing item from the list/Table
    def removeItem(message3):
        strDelete = ()
        while not strDelete:
            strDelete = input("Please Enter Task to be Deleted: ").strip().title()
        # if entry is in the list - using a boolean function
        BlankRemoved = False
        intRow = 0
        while (intRow < len(lstTable)):
            if (strDelete == str(list(dict(lstTable[intRow]).values())[0])):
                del lstTable[intRow]
                BlankRemoved = True
            intRow += 1
        # end for loop
        if (BlankRemoved == True):
            print("\nRemoved Item:", strDelete)
        else:
            print("Item", strDelete, "is not found.")
        # print out the updated list
        print(message3)

    # Step 6
    # Save tasks to the ToDo.txt file
    def saveFile():
        strSave = input(("Do you want to save data into ToDo.txt (Save = Y or Not Save = N)? "))
        if (strSave.lower() == 'y'):
            objFile = open(File, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["task"] + "," + dicRow["priority"] + "\n")
            objFile.close()
            print("You've saved the updated data.")
        else:
            print("Updated Data is not saved.  Original Data is available.")

    # Step 7
    # Exit Program - Part of Presentation Section
#-------------------------------

#--- PRESENTATION ---#
# Step 1 - Extract / Open File using open, append, and close
ToDoList.readFile()

# Step 2
# Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        currentList = ToDoList.showList("Current ToDo List:")

    # Step 4
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        newItem = ToDoList.addItem("\nUpdated ToDo List:")
        for row in lstTable:
            print(row["task"] + " : " + row["priority"])
        continue

    # Step 5
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        # Display Updated List AFTER Targeted Task is removed
        delItem = ToDoList.removeItem("\nUpdated ToDo List AFTER Removed Task:")
        for row in lstTable:
            print(row["task"] + " : " + row["priority"])
        continue

    # Step 6
    # Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        File = ToDoList.saveFile()
        continue

    elif (strChoice == '5'):
        break #and Exit the program
